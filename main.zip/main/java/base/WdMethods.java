package base;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;

import java.sql.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class WdMethods extends WdEventImpl{	

	public WebElement locateElement(String how, String using) {
		WebElement ele = null;
		switch(how) {
		case("id"):
			ele = getEventDriver().findElement(By.id(using));
		break;
		case("name"):
			ele = getEventDriver().findElement(By.name(using));
		break;
		case("linkText"):
			ele = getEventDriver().findElement(By.linkText(using));
		break;
		case("xpath"):
			ele = getEventDriver().findElement(By.xpath(using));
			System.out.println(ele);
		break;
		case("partialLinkText"):
			ele = getEventDriver().findElement(By.partialLinkText(using));
		break;
		case("cssSelector"):
			ele = getEventDriver().findElement(By.cssSelector(using));
		break;
		case("tagName"):
			ele = getEventDriver().findElement(By.tagName(using));
		break;
		case("className"):
			ele = getEventDriver().findElement(By.className(using));
		break;
		default:
			reportStep("The given locator "+how+" is not correct", "FAIL");
			break;
		}
		return ele;			
	}
	
	//Added by Srujana to find the column number that we need to interact with in webtable
	
	public WebElement locateWebTableElement(String columnName,int rowIndex) {
		WebElement ele = null;
		switch("xpath") {
		
		case("xpath"):
			int columnIndex=getEventDriver().findElements(By.xpath("//*[text()='"+columnName+"']/parent::th/preceding-sibling::*")).size()+1;
			ele = getEventDriver().findElement(By.xpath("//*[text()='"+columnName+"']/parent::th/following::tr["+rowIndex+"]/td["+columnIndex+"]"));
			System.out.println(ele);
		
		break;
		
		default:
			reportStep("The given locator xpath is not correct", "FAIL");
			break;
		}
		return ele;			
	}

	public void clear(WebElement ele) {
		ele.clear();
	}

	public void type(WebElement ele, String data) {
		ele.clear();
		ele.sendKeys(data);
	}
	
	public void typeAndTab(WebElement ele, String data) {
		ele.clear();
		ele.sendKeys(data, Keys.TAB);
	}

	public void typeAndChoose(WebElement ele, String data) {
		//ele.clear();
		ele.sendKeys(data);
		pause(5);
		ele.sendKeys(Keys.DOWN, Keys.ENTER);
	}

	public void click(WebElement ele) {
		ele.click();
	}

	public void selectUsingText(WebElement ele, String text) {
		select(ele, "text", text);
	}

	public void selectUsingValue(WebElement ele, String value) {
		select(ele, "value", value);
	}

	public void selectUsingIndex(WebElement ele, int index) {
		new Select(ele).selectByIndex(index);
	}

	private void select(WebElement ele, String type, String textOrValue) {
		if(ele.getTagName().equals("select")) {
			if(type.equalsIgnoreCase("text"))
				new Select(ele).selectByVisibleText(textOrValue);
			else
				new Select(ele).selectByValue(textOrValue);
		}else {
			ele.click();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			}
			//locateElement("xpath", "//li[text()='"+textOrValue+"']").click();			
		}
	}

	public String getText(WebElement ele){
		return ele.getText();
	}	

	public String getAttributeText(WebElement ele, String value){
		return ele.getAttribute(value);
	}

	public boolean verifyText(WebElement ele, String text) {
		return ele.getText().equals(text);
	}

	public boolean verifyPartialText(WebElement ele, String text) {
		return ele.getText().contains(text);
	}	

	public boolean verifyTitle(String title) {
		return getEventDriver().getTitle().equalsIgnoreCase(title);
	}


	public void switchToFrame(WebElement ele) {
		getEventDriver().switchTo().frame(ele);
	}

	public void switchToFrame(int index) {
		getEventDriver().switchTo().frame(index);
	}

	public void acceptAlert() {
		getEventDriver().switchTo().alert().accept();
	}

	public void dismissAlert() {
		getEventDriver().switchTo().alert().dismiss();
	}

	public void sendTextAlert(String txt) {
		getEventDriver().switchTo().alert().sendKeys(txt);
	}

	public String getTextAlert() {
		return getEventDriver().switchTo().alert().getText();
	}	

	public void switchWindow(int index) {
		List<String> lstWindows = new ArrayList<>();
		lstWindows.addAll(getEventDriver().getWindowHandles());
		getEventDriver().switchTo().window(lstWindows.get(index));
	}


	
	
	public void pause(long seconds) {
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void check(WebElement ele) {
		if(!ele.isSelected()) {
			ele.click();
		}
	}
	
	
	public void verifyExists(WebElement ele) {
		if(ele.isDisplayed()) {
			reportStep("The element "+ele+" is visible", "PASS");
		}else {
			reportStep("The element "+ele+" is not visible", "WARNING");
		}
	}
	
	
	//Added by Srujana for DB execution 
	public String  getDatafromdatabase(String sqlQuery) throws FileNotFoundException, IOException, ClassNotFoundException, SQLException
	{
		Properties config = new Properties();
		config.load(new FileInputStream(new File("./src/main/resources/config.properties")));


		// JDBC driver name and database URL
		final String JDBC_DRIVER = config.getProperty("DB_Pkg");  
		final String DB_URL = config.getProperty("DB_Url");

		//  Database credentials
		final String USER = config.getProperty("DB_User");
		final String PASS = config.getProperty("DB_Pwd");

		Connection conn = null;
		Statement stmt = null;

		Class.forName(JDBC_DRIVER);
		conn = DriverManager.getConnection(DB_URL,USER,PASS);
		stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sqlQuery);
		rs.next();
		
		ResultSetMetaData rsmd=rs.getMetaData();
		System.out.println("The db columns are "+rsmd.getColumnName(1));
		System.out.println("the db rows are "+rs.getRow());
		return rs.getString(rsmd.getColumnName(1));
		
		/*rs.close();
		stmt.close();
		conn.close();
		*/
		/*System.out.println(rsmd.getColumnName(1));
		return rs.getString(rsmd.getColumnName(1));
	*/
		
		
		
	}
	
	
	/* Added By Sudarshan */
	public void VerifyElementIsEnabled(WebElement ele)
	{
		if(ele.isEnabled())
		{
			
			reportStep("The element "+ele+" is Enabled", "PASS");
		}else {
			reportStep("The element "+ele+" is Disabled", "WARNING");
		}
	}
	
	/* Added By Sudarshan */
	public void VerifyElementIsDisabled(WebElement ele)
	{
		if(!ele.isEnabled())
		{
			
			reportStep("The element "+ele+" is Disabled", "PASS");
		}else {
			reportStep("The element "+ele+" is Enabled", "WARNING");
		}
	}
	
	/* Added By Sudarshan */
	public void typeandEnter(WebElement ele, String data) {
		ele.clear();
		ele.sendKeys(data,Keys.ENTER);
		
	}
	
	
	public boolean verifyMandatory(String[] elements) {
		
		boolean bMandatory = false;
		String allElements = "";		
		
		// Go to each element
		for (String elementText : elements) {
			WebElement element = locateElement("xpath", "//label[text()='"+elementText+"']/span[@class='mandatory-star']");
			if(element == null) {
				reportStep("The element "+elementText+" is not mandatory", "WARNING");
				bMandatory = false;
			}
			allElements = allElements + elementText + " ";
		}
		
		
		// Report if all successful
		if(bMandatory)
			reportStep("The element(s) "+allElements+" are displayed as mandatory fields", "PASS");
		
		return bMandatory;
	}
	
	
	
	
	
	
}
