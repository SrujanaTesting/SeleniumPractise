package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC004_CreateDespatchBundleAdvice_Error2 extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Despatch BOM - Panel";
		testDescription="Create Despatch BOM - Panel";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC003";
		authors="Babu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber, String error) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.clickSubmit()
		.verifyTextContainsErrorMessage(error);
	}

}
