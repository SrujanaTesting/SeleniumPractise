package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001 extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Login";
		testDescription="Login";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC001";
		authors="Babu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd, String orderType) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickOrderMgmt()
		.clickManufacturingOrders()
		.selectOrderType(orderType)
		.clickGo()
		.clickGridCell()
		.clickUpdate();
		
	}

}
