package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC003_CreateDespatchBOMPanel_CheckwithoutMandory_Error extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Despatch BOM - Panel";
		testDescription="Create Despatch BOM Panel without enterning Mandatory field";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC003_withoutMandatory";
		authors="Babu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickDespatchBOMPanel()
		.clickCreate()
		.clickSubmit()
		.verifyTextContainWarningMsg(warning)
		.CloseWarningMsg();
		
		
		
		
		
	}

}
