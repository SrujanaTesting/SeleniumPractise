package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC003_CreateDespatchBOMPanel_MoveRight extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Despatch BOM - Panel";
		testDescription="Create Despatch BOM - Panel";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC003";
		authors="Babu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String PanelDescription,String Search,String Remarks) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)
		.typePanelDescription(PanelDescription)
		.typeSearch(Search)
		.clickPart()
		.clickBOMPartDetailsFirst()
		.clickMovetoLeft()
		.typeRemarks(Remarks)
		.clickSubmit();
		
		
	}

}
