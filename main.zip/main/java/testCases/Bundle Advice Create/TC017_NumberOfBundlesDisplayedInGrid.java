package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC017_NumberOfBundlesDisplayedInGrid extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Verify the Number of Bundles displayed in the Grid";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC017_NumberOfBundlesDisplayedInGrid";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void DisplayinGrid(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
	    .numberofGriditems();
		
	}
	
	

}
