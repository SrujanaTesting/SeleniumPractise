package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC008_CreateBundleAdvice_SubmitEnabledAfterMandateFields extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Verify Whether the Submit Button is enabled after entering the Mandatory fields";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC008_CreateBundleAdvice_SubmitEnabledAfterMandateFields";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void SubmitEnabled(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode,String BundleQuantity ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.checkBundleCheckbox()
		.clickRequiredBundleQuantityText()
		.typeBundleQuantity(BundleQuantity)
		.SubmitButtonISEnabled();
		
	}
	
	

}
