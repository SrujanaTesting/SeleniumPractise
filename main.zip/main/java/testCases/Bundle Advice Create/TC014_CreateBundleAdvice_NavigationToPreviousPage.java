package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC014_CreateBundleAdvice_NavigationToPreviousPage extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Pagination -navigation to Previous Page";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC014_CreateBundleAdvice_NavigationToPreviousPage";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void navigationToPreviousPage(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
	    .navigateNextpage()
	    .navigateLPreviouspage()
		.verifyExistsBundleCode()
		.verifyExistsBundleStock()
		.verifyExistsRequiredBundleQuantity();
		
	}
	
	

}
