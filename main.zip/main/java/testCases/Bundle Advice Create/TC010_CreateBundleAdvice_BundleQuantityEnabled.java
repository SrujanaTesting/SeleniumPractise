package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC010_CreateBundleAdvice_BundleQuantityEnabled extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Verify Whether the Required Bundle Quantity Field is Enabled After Checking the BundleCode Check Box ";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC010_CreateBundleAdvice_BundleQuantityEnabled";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void RBQEnabled(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.checkBundleCheckbox()
		.RequiredBundleQuantityEnabled();
		
	}
	
	

}
