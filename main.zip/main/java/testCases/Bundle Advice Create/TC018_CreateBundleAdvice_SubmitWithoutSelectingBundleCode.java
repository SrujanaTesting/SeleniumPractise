package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC018_CreateBundleAdvice_SubmitWithoutSelectingBundleCode extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice -Without Checking the Bundle Code";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC018_CreateBundleAdvice_SubmitWithoutSelectingBundleCode";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundlewithoutBundleCode(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode,String error) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.clickSubmit()
		.verifyTextContainsErrorMessagenotCheckingBundle(error);
		
	}
	
	

}
