package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC011_CreateBundleAdvice_VerifyTheResetButtonFunctionality extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Verify Whether the entered Fields are cleared after clicking the Reset Button ";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC011_CreateBundleAdvice_VerifyTheResetButtonFunctionality";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void ResetFunctionality(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode,String BundleQuantity,String OrdAftReset,String LotVal,String LotAftReset,String prodval,String PrdAftReset,String panval,String PanAftReset) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.checkBundleCheckbox()
		.clickRequiredBundleQuantityText()
		.typeBundleQuantity(BundleQuantity)
        .clickReset() 
        .IsorderNumberEmpty(OrdAftReset)
        .LotNumberIsNull(LotVal,LotAftReset)
        .ProductCodeIsEmpty(prodval,PrdAftReset)
        .PanelCodeIsEmpty(panval,PanAftReset);
		
	}
	
	

}
