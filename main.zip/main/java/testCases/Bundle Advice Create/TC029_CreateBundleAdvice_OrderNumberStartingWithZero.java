package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC029_CreateBundleAdvice_OrderNumberStartingWithZero extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice order number starts with zero";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC029_CreateBundleAdvice_OrderNumberStartingWithZero";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundleInvalidOrder(String uName, String pwd,String OrderNumber,String error ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.verifyTextContainsErrorInvalidOrder(error);
	}
	
	

}
