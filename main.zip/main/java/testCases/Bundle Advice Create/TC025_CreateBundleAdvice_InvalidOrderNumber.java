package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC025_CreateBundleAdvice_InvalidOrderNumber extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice  with Invalid Order Number";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC025_CreateBundleAdvice_InvalidOrderNumber";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void InvalidOrderNumber(String uName, String pwd,String OrderNumber,String error ) 
	{
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
        .verifyTextContainsErrorInvalidOrder(error);
		
	}
	

}
