package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC024_CreateBundleAdvice_RequiredBundleQuantityisZero extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice  with Required bundle quantity is zero";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC024_CreateBundleAdvice_RequiredBundleQuantityisZero";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void RBQZero(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode,String BundleQuantity,String error ) 
	{
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.checkBundleCheckbox()
		.clickRequiredBundleQuantityText()
		.typeBundleQuantity(BundleQuantity)
		.clickSubmit()
		.verifyTextContainsErrorReqBundleZero(error);
		
	}
	

}
