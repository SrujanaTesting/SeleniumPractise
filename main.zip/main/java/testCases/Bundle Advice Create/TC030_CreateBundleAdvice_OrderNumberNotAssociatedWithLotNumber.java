package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC030_CreateBundleAdvice_OrderNumberNotAssociatedWithLotNumber extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice order number no associated with lotNumber";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC030_CreateBundleAdvice_OrderNumberNotAssociatedWithLotNumber";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundleInvalidOrder(String uName, String pwd,String OrderNumber,String LotVal,String LotNum  ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.LotNumberIsNull(LotVal,LotNum);
	
	

}

}