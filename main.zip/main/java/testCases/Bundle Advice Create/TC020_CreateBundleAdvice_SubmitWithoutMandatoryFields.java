package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC020_CreateBundleAdvice_SubmitWithoutMandatoryFields extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice -without Entering the mandatory fields Order Number ,Lot Number and Panel Code ";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC020_CreateBundleAdvice_SubmitWithoutMandatoryFields";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundlewithoutMandatory(String uName, String pwd,String error) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.clickSubmit()
		.verifyTextContainsErrorMessagenotEnteringMandtoryFields(error);
	}
	
	

}
