package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC006_CreateBundleAdvice_SelectingAlltheBundleCode extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Bundle Advice Creation Selecting All the BundleCodes";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC006_CreateBundleAdvice_SelectingAlltheBundleCode";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void AllBundleCodes(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode,String BundleQuantity,String dataSuccessMessage ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.CheckAllBundleCodeCheckBox()
		.clickAndTypeMultipleBundleQuantity(BundleQuantity)
		.clickSubmit()
		.verifyTextContainsSuccessMessage(dataSuccessMessage)
		.clickCloseSuccessMessage();
	}
	
	

}
