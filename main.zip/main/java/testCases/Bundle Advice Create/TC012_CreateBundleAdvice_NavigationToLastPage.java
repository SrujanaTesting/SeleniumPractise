package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC012_CreateBundleAdvice_NavigationToLastPage extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Page -Navigation -to Last page in Bundle Details";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC012_CreateBundleAdvice_NavigationToLastPage";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void navigationToLastpage(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
	    .navigateLastpage()
		.verifyExistsBundleCode()
		.verifyExistsBundleStock()
		.verifyExistsRequiredBundleQuantity();
		
	}
	
	

}
