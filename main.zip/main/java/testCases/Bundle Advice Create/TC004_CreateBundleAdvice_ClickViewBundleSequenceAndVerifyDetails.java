package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC004_CreateBundleAdvice_ClickViewBundleSequenceAndVerifyDetails extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Successful Bundle Advice Creation and Verifying VBundle Sequence details";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC004_CreateBundleAdvice_ClickViewBundleSequenceAndVerifyDetails";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundleVerifyBundleSequence(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode,String dataSuccessMessage ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.checkBundleCheckbox()
		.clickRequiredBundleQuantityText()
		.typeReqBundleQuantityLesserThanBundleStock()
		.clickSubmit()
		.verifyTextContainsSuccessMessage(dataSuccessMessage)
		.clickViewBundleSequenceNumbers()
		.verifyExistsBundleAdviceGenerated()
		.verifyExistsBundleCodeDetails()
		.verifyExistsFromBundleSequenceNumber()
		.verifyExistsToBundleSequenceNumber()
		.clickCloseBundleSequenceNumberDetails()
		.clickCloseSuccessMessage();
	}
	
	

}
