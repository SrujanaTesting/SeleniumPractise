package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC002_CreateBundleAdvice_WithoutProductCode extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice without selecting the Non Mandatory field Product code";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC002_CreateBundleAdvice_WithoutProductCode";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundleMandatoryFields(String uName, String pwd,String OrderNumber,String LotNumber,String PanelCode,String BundleQuantity,String dataSuccessMessage ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextPanelCode(PanelCode)
		.checkBundleCheckbox()
		.clickRequiredBundleQuantityText()
		.typeBundleQuantity(BundleQuantity)
		.clickSubmit()
		.verifyTextContainsSuccessMessage(dataSuccessMessage)
		.clickViewBundleSequenceNumbers()
		.verifyExistsBundleAdviceGenerated()
		.verifyExistsBundleCodeDetails()
		.verifyExistsFromBundleSequenceNumber()
		.verifyExistsToBundleSequenceNumber()
		.clickCloseBundleSequenceNumberDetails()
		.clickCloseSuccessMessage();
	}
	
	

}
