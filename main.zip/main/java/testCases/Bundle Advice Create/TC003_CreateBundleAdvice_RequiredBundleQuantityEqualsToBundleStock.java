package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC003_CreateBundleAdvice_RequiredBundleQuantityEqualsToBundleStock extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice  with Required bundle quantity equal to Bundle stock quantity";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC003_CreateBundleAdvice_RequiredBundleQuantityEqualsToBundleStock";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundleRBQequalsBSQ(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode,String dataSuccessMessage ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.checkBundleCheckbox()
		.clickRequiredBundleQuantityText()
		.typeReqBundleQuantityequalToBundleStock()
		.clickSubmit()
		.verifyTextContainsSuccessMessage(dataSuccessMessage)
		.clickViewBundleSequenceNumbers()
		.verifyExistsBundleAdviceGenerated()
		.verifyExistsBundleCodeDetails()
		.verifyExistsFromBundleSequenceNumber()
		.verifyExistsToBundleSequenceNumber()
		.clickCloseBundleSequenceNumberDetails()
		.clickCloseSuccessMessage();
	}
	
	

}
