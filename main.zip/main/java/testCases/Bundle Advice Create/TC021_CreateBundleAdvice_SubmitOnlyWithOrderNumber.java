package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC021_CreateBundleAdvice_SubmitOnlyWithOrderNumber extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice -Submit Only Entering the Order Number without Selecting Lot Number and Panel code";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC021_CreateBundleAdvice_SubmitOnlyWithOrderNumber";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundleNegative1(String uName, String pwd,String OrderNumber,String error,String error1) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.clickSubmit()
		.typeAndChooseOrderNumber(OrderNumber)
		.verifyTextContainsErrorMessagenotEnteringLotNumber(error)
		.verifyTextContainsErrorMessagenotEnteringPanelCode(error1);
	
		
	}
	
	

}
