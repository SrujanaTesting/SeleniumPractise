package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_CreateBundleAdvice_SingleBundleCode extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice with single Bundle code";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC001_CreateBundleAdvice_SingleBundleCode";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundle(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode,String BundleQuantity,String dataSuccessMessage ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.checkBundleCheckbox()
		.clickRequiredBundleQuantityText()
		.typeBundleQuantity(BundleQuantity)
		.clickSubmit()
		.verifyTextContainsSuccessMessage(dataSuccessMessage)
		.clickViewBundleSequenceNumbers()
		.verifyExistsBundleAdviceGenerated()
		.verifyExistsBundleCodeDetails()
		.verifyExistsFromBundleSequenceNumber()
		.verifyExistsToBundleSequenceNumber()
		.clickCloseBundleSequenceNumberDetails()
		.clickCloseSuccessMessage();
	}
	
	

}
