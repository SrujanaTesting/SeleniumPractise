package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC022_CreateBundleAdvice_SubmitOnlyWithOrderNumberandLotNumber extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice -Submit Only Entering the Order Number ,LotNumber without selecting Panel code";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC022_CreateBundleAdvice_SubmitOnlyWithOrderNumberandLotNumber";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundleNegative2(String uName, String pwd,String OrderNumber,String LotNumber, String error) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.clickSubmit()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.verifyTextContainsErrorMessagenotEnteringPanelCode(error);
	
		
	}
	
	

}
