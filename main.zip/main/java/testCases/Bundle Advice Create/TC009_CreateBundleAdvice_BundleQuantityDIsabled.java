package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC009_CreateBundleAdvice_BundleQuantityDIsabled extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Verify Whether the Required Bundle Quantity Field is Disabled Before Checking the BundleCode Check Box ";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC009_CreateBundleAdvice_BundleQuantityDIsabled";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void RBQDisabled(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.RequiredBundleQuantityDisabled();
		
	}
	
	

}
