package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC019_CreateBundleAdvice_SubmitWithoutEnteringRequiredBundleQuantity extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice -without Entering the Required Bundle Details for the Bundle Stock";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC019_CreateBundleAdvice_SubmitWithoutEnteringRequiredBundleQuantity";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundlewithoutBundleQuanityt(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode,String error) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.checkBundleCheckbox()
		.clickSubmit()
		.verifyTextContainsErrorMessagenotEnteringBundleQuantity(error);
		
	}
	
	

}
