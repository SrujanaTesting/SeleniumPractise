package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC016_CreateBundleAdvice_NavigationEnteringPageNumber extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Page -Navigation -Entering the page Number in Bundle Details";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC016_CreateBundleAdvice_NavigationEnteringPageNumber";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void navigationEnteringpage(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode, String PageNumber) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
	    .EnterPageNumber(PageNumber)
		.verifyExistsBundleCode()
		.verifyExistsBundleStock()
		.verifyExistsRequiredBundleQuantity();
		
	}
	
	

}
