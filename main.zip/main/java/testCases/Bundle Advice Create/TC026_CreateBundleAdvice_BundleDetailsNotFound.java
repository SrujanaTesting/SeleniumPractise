package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC026_CreateBundleAdvice_BundleDetailsNotFound extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice order number not associated with the Bundle";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC026_CreateBundleAdvice_BundleDetailsNotFound";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundleInvalidOrder(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode,String error ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
		.verifyTextContainsErrorBundleDetailsNotFound(error);
	}
	
	

}
