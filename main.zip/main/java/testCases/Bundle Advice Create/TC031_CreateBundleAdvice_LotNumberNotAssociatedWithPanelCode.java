package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC031_CreateBundleAdvice_LotNumberNotAssociatedWithPanelCode extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Create Bundle advice Lot number no associated with PanelCode";
		category="Functional-Negative";
		dataSource="Excel";
		dataSheetName="TC031_CreateBundleAdvice_LotNumberNotAssociatedWithPanelCode";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void CreateBundleInvalidOrder(String uName, String pwd,String OrderNumber,String LotNumber ,String Panval ,String pancode ) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		 .PanelCodeIsEmpty(Panval,pancode);
	
	

}

}