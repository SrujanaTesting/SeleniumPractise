package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC013_CreateBundleAdvice_NavigationToNextPage extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Create Bundle Advice";
		testDescription="Page -Navigation -to Next page in Bundle Details";
		category="Functional-Positive";
		dataSource="Excel";
		dataSheetName="TC013_CreateBundleAdvice_NavigationToNextPage";
		authors="Sudarshan";
	}
	
	@Test(dataProvider ="fetchData")
	public void navigationToNextPage(String uName, String pwd,String OrderNumber,String LotNumber,String ProductCode,String PanelCode) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickBundleAdvise()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextLotNumber(LotNumber)
		.selectUsingTextProductCode(ProductCode)
		.selectUsingTextPanelCode(PanelCode)
	    .navigateNextpage()
		.verifyExistsBundleCode()
		.verifyExistsBundleStock()
		.verifyExistsRequiredBundleQuantity();
		
	}
	
	

}
