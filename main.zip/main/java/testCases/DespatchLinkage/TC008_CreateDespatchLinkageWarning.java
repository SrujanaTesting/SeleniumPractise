package testCases.DespatchLinkage;

import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC008_CreateDespatchLinkageWarning extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="CreateDespatchLinkage";
		testDescription="CreateDespatchLinkage";
		category="smoke";
		dataSource="excel";
		//sqlStatement="Select TOP 1 HPL_Order_Number from EIPPDSS.PDSPLN.PLN_H_Production_Linkage where ISNUMERIC(HPL_LOT_Number) = 0 ORDER BY NEWID()";
		dataSheetName="sample2";
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password,String OrderNumber,String ConsigneeCode,String lotNumber) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(3000);
		new CreateDespatchLinkage()
		.verifyMandatoryFields()
		.typeOrderNumber(OrderNumber)
		.clickOrderinfo()
		.verifyInfoDetails()
		.typeConsignee(ConsigneeCode)
		.clickConsigneeInfo()
		.verifyInfoDetails()
		.clickLotNumber()
		.SelectLotNumber(lotNumber)
		.clickGetProducts()
		.enterQuantityAboveExpected()   // this should be refactored
		.getdialogMsg();
	}


}
