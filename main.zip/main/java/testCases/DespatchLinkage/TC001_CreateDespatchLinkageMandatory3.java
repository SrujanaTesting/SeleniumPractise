package testCases.DespatchLinkage;

import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC001_CreateDespatchLinkageMandatory3 extends PreAndPost{
	
	@BeforeClass()
	public void setValues() {
		browserName="internet explorer";
		testCaseName="CreateDespatchLinkage";
		testDescription="CreateDespatchLinkage";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC008";
		authors="Ramki";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ConsigneeCode,String lotNumber,String columnName) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(3000);
		new CreateDespatchLinkage()
		.typeOrderNumber(OrderNumber)
		.typeConsignee(ConsigneeCode)
		.clickGetProducts()
		.getdialogMsg()
		.CloseMessage();
		
	}


}
