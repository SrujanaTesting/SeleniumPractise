package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC002 extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Login";
		testDescription="Login";
		category="smoke";
		dataSource="db";
		dataSheetName="TC001";
		sqlStatement="SELECT HPBOM_Order_Number, HPBOM_BOM_Code FROM EIPPDSS.PDSDGN.DGN_H_Production_BOM WHERE HPBOM_BOM_Stage_Code = 3 and HPBOM_Amendment_Date is NULL";
		authors="Babu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String orderNumber, String productNumber) {
		
		System.out.println(orderNumber);
		System.out.println(productNumber);
		
	}

}
