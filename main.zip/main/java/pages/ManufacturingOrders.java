package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ManufacturingOrders extends AbstractPage{

	String sessionId;

	public ManufacturingOrders() {
		PageFactory.initElements(getEventDriver(), this);
	}
	
	@FindBy(how = How.ID, using = "update")
	private WebElement eleupdate;
		
	public ManufacturingOrders clickUpdate() {
		click(eleupdate);
		return this;
	}
	
	

	
}
