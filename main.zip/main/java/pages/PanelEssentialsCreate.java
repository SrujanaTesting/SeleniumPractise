package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Sleeper;

import cucumber.api.java.en.When;


public class PanelEssentialsCreate extends AbstractPage  {

	public PanelEssentialsCreate(){
		PageFactory.initElements(getEventDriver(), this);
	}
	@FindBy(how=How.XPATH,using="//span[@onclick='UserSelectClick()']")

	public WebElement eleMovetoRight;
	public PanelEssentialsCreate clickMovetoRight(){
		click(eleMovetoRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleMoveAllRight;
	public PanelEssentialsCreate clickMoveAllRight(){
		click(eleMoveAllRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleMovetoLeft;
	public PanelEssentialsCreate clickMovetoLeft(){
		click(eleMovetoLeft);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleMoveAllLeft;
	public PanelEssentialsCreate clickMoveAllLeft(){
		click(eleMoveAllLeft);
		return this;
	}
	
	@FindBy(how=How.ID,using="OrderNumber")
    
	public WebElement eleOrderNumber;
	@When ("The OrderNumber entered")
	public PanelEssentialsCreate typeAndChooseOrderNumber(String dataOrderNumber){
		click(eleOrderNumber);
		pause(3);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[@class='k-select']")

	public WebElement eleProductCode;
	public PanelEssentialsCreate selectUsingTextProductCode(String dataProductCode){
		selectUsingText(eleProductCode, dataProductCode);
		return this;
	}
	@FindBy(how=How.ID,using="//*[@id='PannelCode']/parent::span")

	public WebElement elePanelCode;
	public PanelEssentialsCreate typePanelCode(String dataPanelCode){
		//selectUsingText(elePanelCode, dataPanelCode);
		type(elePanelCode,dataPanelCode);
		return this;
	}
	@FindBy(how=How.ID,using="txtRemarks")

	public WebElement eleRemarks;
	public PanelEssentialsCreate typeRemarks(String dataRemarks){
		type(eleRemarks, dataRemarks);
		return this;
	}
	@FindBy(how=How.ID,using="PannelDescription")

	public WebElement elePanelDescription;
	public PanelEssentialsCreate typePanelDescription(String dataPanelDescription){
		type(elePanelDescription, dataPanelDescription);
		return this;
	}
	@FindBy(how=How.ID,using="SubmitAssociation")

	public WebElement eleSubmit;
	public PanelEssentialsCreate clickSubmit(){
		click(eleSubmit);
		return this;
	}
	@FindBy(how=How.ID,using="Search")

	public WebElement eleSearch;
	public PanelEssentialsCreate typeSearch(String dataSearch){
		type(eleSearch, dataSearch);
		return this;
	}
	@FindBy(how=How.XPATH,using="//input[@value='Part']")

	public WebElement elePart;
	public PanelEssentialsCreate clickPart(){
		click(elePart);
		return this;
	}
	@FindBy(how=How.XPATH,using="//div[@id='BOMPartDetails']//tbody/tr[1]")

	public WebElement eleBOMPartDetailsFirst;
	public PanelEssentialsCreate clickBOMPartDetailsFirst(){
		click(eleBOMPartDetailsFirst);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[@id='BOMPartDetails']//tbody/tr") //Need to implement
	public List<WebElement> eleBOMPartDetails;
	public PanelEssentialsCreate MultipleSelectPartDetails() {
		
		
		return this;
	}
	
	@FindBy(how=How.ID,using="btnReset")

	private WebElement eleReset;
	public  PanelEssentialsCreate clickReset(){
		click(eleReset);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='OrderNumber']/../following-sibling::i")

	public WebElement eleOrderNuminfo;
	public PanelEssentialsCreate clickOrderNumberInfo(String dataWarningMessage){
		click(eleOrderNuminfo);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='ProductCode']/../following-sibling::i")

	public WebElement eleProductCodeinfo;
	public PanelEssentialsCreate clickProductCodeInfo(String dataWarningMessage){
		click(eleProductCodeinfo);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//*[text()='Success']")

	public WebElement eleSuccessDespatchLinkage;
	public PanelEssentialsCreate verifySuccessMsg(String data){
		verifyText(eleSuccessDespatchLinkage, data);
		return this;
	}
	

	@FindBy(how=How.ID,using="btnyes")    

	public WebElement eleYesSuccess;
	@When ("Click on Yes")
	public PanelEssentialsCreate clickYesSuccess(){
		click(eleYesSuccess);
		return this;
	}

	
	
	@FindBy(how=How.ID,using="btnno")    

	public WebElement eleNoSuccess;
	@When ("Click on No")
	public PanelEssentialsCreate clickYesConfirmation(){
		
		click(eleNoSuccess);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleErrorMessage;
	public PanelEssentialsCreate verifyTextContainWarningMsg(String warning) {

		verifyPartialText(eleErrorMessage, warning);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//span[text()='Close']/..)[1]") 
	private WebElement closeMessage; 
	public PanelEssentialsCreate  CloseWarningMsg()
	{
		click(closeMessage);
		return this;
	}
	
	
	
	public PanelEssentialsCreate OrderNumberIsNull(String value)
	{
		
		
		String OrdeNumberAttribute = getAttributeText(eleOrderNumber,value);
		if(OrdeNumberAttribute.isEmpty())
		{
			reportStep("The element "+eleOrderNumber+" is contains value", "PASS");
		}else {
			reportStep("The element "+eleOrderNumber+" is Empty", "WARNING");
		}
		
		return this;

	}
	
	public PanelEssentialsCreate ProductCodeIsNull(String value,String ProductCode)
	{
		
		
		String ProductCodeAttribute = getAttributeText(eleProductCode, value);
		if(ProductCodeAttribute.contains(ProductCode))
		{
			reportStep("The element "+eleProductCode+" is contains value", "PASS");
		}else {
			reportStep("The element "+eleProductCode+" is Empty", "WARNING");
		}
		
		return this;

	}
	
	public PanelEssentialsCreate PanelCodeIsNull(String value,String PanelCode)
	{
		
		
		String ProductCodeAttribute = getAttributeText(elePanelCode, value);
		if(ProductCodeAttribute.contains(PanelCode))
		{
			reportStep("The element "+elePanelCode+" is contains value", "PASS");
		}else {
			reportStep("The element "+elePanelCode+" is Empty", "WARNING");
		}
		
		return this;

	}
	

	


}
