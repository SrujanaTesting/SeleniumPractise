package pages;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;





public class CreateBundleAdvice extends AbstractPage  {

public CreateBundleAdvice(){
		
		// This is to load all the elements in the page
		PageFactory.initElements(driver, this);

}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleOrderNumber;
public CreateBundleAdvice typeAndChooseOrderNumber(String dataOrderNumber){
	typeAndChoose(eleOrderNumber, dataOrderNumber);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleLotNumber;
public CreateBundleAdvice selectUsingTextLotNumber(String dataLotNumber){
	selectUsingText(eleLotNumber, dataLotNumber);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleProductCode;
public CreateBundleAdvice selectUsingTextProductCode(String dataProductCode){
	selectUsingText(eleProductCode, dataProductCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement elePanelCode;
public CreateBundleAdvice selectUsingTextPanelCode(String dataPanelCode){
	selectUsingText(elePanelCode, dataPanelCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBundleCheckbox;
public CreateBundleAdvice checkBundleCheckbox(){
	check(eleBundleCheckbox);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleRequiredBundleQuantityText;
public CreateBundleAdvice clickRequiredBundleQuantityText(){
	click(eleRequiredBundleQuantityText);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleSubmit;
public CreateBundleAdvice clickSubmit(){
	click(eleSubmit);
	return this;
}	
@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleReset;
	public CreateBundleAdvice clickReset(){
		click(eleReset);
		return this;
	}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBundleQuantity;
public CreateBundleAdvice typeBundleQuantity(String dataBundleQuantity){
	type(eleBundleQuantity, dataBundleQuantity);
	return this;
}

/*Added to Enter the required Bundle Quantity equal to the Bundle Stock Quantity 
* Added By-Sudarshan
* */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBundleStockQuantity;
public CreateBundleAdvice typeReqBundleQuantityequalToBundleStock(){

	String bundlestockquanity = getText(eleBundleStockQuantity);
	int bundlestock=Integer.parseInt(bundlestockquanity);
	int enterBundlequanity=bundlestock;
	
	if(bundlestock>=1)
	{
		String bundlequanity = Integer.toString(enterBundlequanity);
		type(eleBundleQuantity, bundlequanity);
	}
	return this;
			
}

/* Added to Enter the required Bundle Quantity greater than  Bundle Stock Quantity 
 * Added By-Sudarshan
 * */

public CreateBundleAdvice typeReqBundleQuantityGreaterThanBundleStock(){

	String bundlestockquanity = getText(eleBundleStockQuantity);
	int bundlestock=Integer.parseInt(bundlestockquanity);
	int enterBundlequanitygreaterthanBundleStock=bundlestock+1;
	
	if(bundlestock>=1)
	{
		String bundlequanity = Integer.toString(enterBundlequanitygreaterthanBundleStock);
		type(eleBundleQuantity, bundlequanity);
	}
	return this;
			
}

/* Added to Enter the required Bundle Quantity lesser than  Bundle Stock Quantity 
 * Added By-Sudarshan
 */

public CreateBundleAdvice typeReqBundleQuantityLesserThanBundleStock(){

	String bundlestockquanity = getText(eleBundleStockQuantity);
	int bundlestock=Integer.parseInt(bundlestockquanity);
	int enterBundlequanity=bundlestock-1;
	int enterNonzeroBundlequantity=bundlestock;
	
	if(bundlestock>=1 && enterBundlequanity!=0)
	{
		String bundlequanity = Integer.toString(enterBundlequanity);
		type(eleBundleQuantity, bundlequanity);
	}
	
	else
	{ 
		String NonzeroBundleQuanity = Integer.toString(enterNonzeroBundlequantity);
		type(eleBundleQuantity, NonzeroBundleQuanity);
	}
	return this;
	
}


/*Added to Verify the ToolTip Information
 * Added By Sudarshan 
 * Verification is done with the Ordernumber
*/


@FindBy(how=How.XPATH,using="Dummy")
public WebElement eleOrderNumberToolTip;
public CreateBundleAdvice VerifyOrderNumberToolTip(String toolTip)
{
	verifyPartialText(eleOrderNumberToolTip,toolTip);
	return this;
}


/*Added to select muliple the Bundlecodes displayed for the Bundle details
 * Added By Sudarshan 
*/
@FindBy(how=How.XPATH,using="Dummy")
public List <WebElement> listCheckMultipleBundle;

public CreateBundleAdvice CheckMultipleBundleCodes()
{
	for(WebElement i : listCheckMultipleBundle)
	{
		check(i);
	}
	
	return this;
}


/*Added to select all the Bundlecode displayed for the Bundle details
 * Added By Sudarshan 
*/

@FindBy(how=How.XPATH,using="Dummy")
public WebElement eleCheckAllBundleCode;

public CreateBundleAdvice CheckAllBundleCodeCheckBox()
{
	check(eleCheckAllBundleCode);
	
	return this;
}

/* Added to Click and type value on the Required Bundle Quantity field when Multiple Bundles are selected
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")
public List <WebElement> listClickBundleQuanity;

public CreateBundleAdvice clickAndTypeMultipleBundleQuantity(String bundleQuantity)
{
	for(WebElement i : listClickBundleQuanity)
	{
		click(i);
		type(i, bundleQuantity);
	
	}
	return this;
}

/* Added to verify whether the Submit button is Enabled
 * Added By Sudarshan
 */

public CreateBundleAdvice SubmitButtonISEnabled()
{
	
	VerifyElementIsEnabled(eleSubmit);
	return this;
} 


/* Added to verify whether the Submit button is Disabled
 * Added By Sudarshan
 */

public CreateBundleAdvice SubmitButtonISDisabled()
{
	
	VerifyElementIsDisabled(eleSubmit);
	return this;
} 

/* Added to verify whether the  Bundle quantity field Enabled
 * Added By Sudarshan
 */

public CreateBundleAdvice RequiredBundleQuantityEnabled()
{
	
	VerifyElementIsEnabled(eleRequiredBundleQuantityText);
	return this;
} 

/* Added to verify whether the  Bundle quantity field Disabled
 * Added By Sudarshan
 */

public CreateBundleAdvice RequiredBundleQuantityDisabled()
{
	
	VerifyElementIsDisabled(eleRequiredBundleQuantityText);
	return this;
} 


/* Added to verify whether the  order number field is Null
 * Added By Sudarshan
 */

public CreateBundleAdvice IsorderNumberEmpty(String value)
{
	
	
	String OrdeNumberAttribute = getAttributeText(eleOrderNumber, value);
	if(OrdeNumberAttribute.isEmpty())
	{
		reportStep("The element "+eleOrderNumber+" is Empty", "PASS");
	}else {
		reportStep("The element "+eleOrderNumber+" is contains value", "WARNING");
	}
	
	return this;

}


/*Added to verify whether the LotNumber Field is Null
 * Added By Sudarshan
 */


public CreateBundleAdvice LotNumberIsNull(String value,String LotNumber)
{
	
	
	String OrdeNumberAttribute = getAttributeText(eleLotNumber, value);
	if(OrdeNumberAttribute.contains(LotNumber))
	{
		reportStep("The element "+eleLotNumber+" is contains value", "PASS");
	}else {
		reportStep("The element "+eleLotNumber+" is Empty", "WARNING");
	}
	
	return this;

}


/*Added to Verify whether the Product code field is Null
 * Added By Sudarshan
 */

public CreateBundleAdvice ProductCodeIsEmpty(String value,String ProductCode)
{
	

	String OrdeNumberAttribute = getAttributeText(eleProductCode, value);
	if(OrdeNumberAttribute.contains(ProductCode))
	{
		reportStep("The element "+eleProductCode+" is contains value", "PASS");
	}else {
		reportStep("The element "+eleProductCode+" is Empty", "WARNING");
	}
	
	return this;

}


/*Added to Verify whether the Panel code field is Null
 * Added By Sudarshan
 */

public CreateBundleAdvice PanelCodeIsEmpty(String value,String PanelCode)
{
	
	
	String OrdeNumberAttribute = getAttributeText(eleProductCode, value);
	if(OrdeNumberAttribute.contains(PanelCode))
	{
		reportStep("The element "+elePanelCode+" is Empty", "PASS");
	}else {
		reportStep("The element "+elePanelCode+" is contains value", "WARNING");
	}
	
	return this;

}

/* Pagination-Click Last page
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")
public WebElement eleClickLastpage;
public CreateBundleAdvice navigateLastpage()
{
	
	click(eleClickLastpage);
	return this;
}


/* Pagination-Click Previous page
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")
public WebElement eleClickPreviouspage;
public CreateBundleAdvice navigateLPreviouspage()
{
	
	click(eleClickPreviouspage);
	return this;
}


/* Pagination-Click Next page
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")
public WebElement eleClickNextpage;
public CreateBundleAdvice navigateNextpage()
{
	
	click(eleClickNextpage);
	return this;
}

/* Pagination-Click first page
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")
public WebElement eleClickFirstpage;
public CreateBundleAdvice navigateFirstpage()
{
	
	click(eleClickFirstpage);
	return this;
}


/* Pagination-Enter page Number and Click enter to navigate to the page
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")
public WebElement elePageNumber;
public CreateBundleAdvice EnterPageNumber(String PageNumber)
{
	click(elePageNumber);
	typeandEnter(elePageNumber, PageNumber);
	return this;
	
}

/* Verify the Bundlecode in the Grid 
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBundleCode;
public CreateBundleAdvice verifyExistsBundleCode(){
	verifyExists(eleBundleCode);
	return this;
}


/* Verify the BundleStock in the Grid 
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBundleStockGrid;
public CreateBundleAdvice verifyExistsBundleStock(){
	verifyExists(eleBundleStockGrid);
	return this;
}


/* Verify the Required Bundle Quantity in the Grid 
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleReqBunQunatityGrid;
public CreateBundleAdvice verifyExistsRequiredBundleQuantity(){
	verifyExists(eleReqBunQunatityGrid);
	return this;
}

/* Display the RNumber of Bundles in the Grid
 * Added By Sudarshan
 */
@FindBy(how=How.XPATH,using="Dummy")

public WebElement elenumberofGriditems;
public CreateBundleAdvice numberofGriditems(){

	String GridItems = getText(elenumberofGriditems);
	reportStep("Number of BundleCodes "+GridItems+" is displayed in this page" ,"PASS");
	
	return this;
}



/* Display error message for not selecting the Bundle Code
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorMessagenotCheckingBundle;
public CreateBundleAdvice verifyTextContainsErrorMessagenotCheckingBundle(String error) {
	
	verifyPartialText(eleErrorMessagenotCheckingBundle, error);
	return this;
}

/* Display error message for not Entering the Bundle quantity
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorMessagenotEnteringBundleQuantity;
public CreateBundleAdvice verifyTextContainsErrorMessagenotEnteringBundleQuantity(String error) {
	
	verifyPartialText(eleErrorMessagenotEnteringBundleQuantity, error);
	return this;
}


/* Display error message for not Entering the mandatory fields to create Bundle Advice
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorMessagenotEnteringMandtoryFields;
public CreateBundleAdvice verifyTextContainsErrorMessagenotEnteringMandtoryFields(String error) {
	
	verifyPartialText(eleErrorMessagenotEnteringMandtoryFields, error);
	return this;
}

/* Display error message for not Entering the OrderNumber field to create Bundle Advice
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorMessagenotEnteringOrderNumber;
public CreateBundleAdvice verifyTextContainsErrorMessagenotEnteringOrderNumber(String error) {
	
	verifyPartialText(eleErrorMessagenotEnteringOrderNumber, error);
	return this;
}

/* Display error message for not Entering the LotNumber field to create Bundle Advice
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorMessagenotEnteringLotNumber;
public CreateBundleAdvice verifyTextContainsErrorMessagenotEnteringLotNumber(String error) {
	
	verifyPartialText(eleErrorMessagenotEnteringLotNumber, error);
	return this;
}

/* Display error message for not Entering the PanelCode field to create Bundle Advice
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorMessagenotEnteringPanelCode;
public CreateBundleAdvice verifyTextContainsErrorMessagenotEnteringPanelCode(String error) {
	
	verifyPartialText(eleErrorMessagenotEnteringPanelCode, error);
	return this;
}

/* Display error message Required Bundle Quantity greater than Bundle Stock
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorReqBungreaterThanStock;
public CreateBundleAdvice verifyTextContainsErrorReqBungreaterThanStock(String error) {
	
	verifyPartialText(eleErrorReqBungreaterThanStock, error);
	return this;
}


/* Display error message Required Bundle Quantity is zero
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorReqBundleZero;
public CreateBundleAdvice verifyTextContainsErrorReqBundleZero(String error) {
	
	verifyPartialText(eleErrorReqBundleZero, error);
	return this;
}

/* Display error message for Invalid Order Number
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorInvalidOrder;
public CreateBundleAdvice verifyTextContainsErrorInvalidOrder(String error) {
	
	verifyPartialText(eleErrorInvalidOrder, error);
	return this;
}


/* Display error message for Bundle Details Not Found
 * Added By Sudarshan
 */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorBundleDetailsNotFound;
public CreateBundleAdvice verifyTextContainsErrorBundleDetailsNotFound(String error) {
	
	verifyPartialText(eleErrorBundleDetailsNotFound, error);
	return this;
}






@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleSuccessMessage;
public CreateBundleAdvice verifyTextContainsSuccessMessage(String dataSuccessMessage){
	verifyPartialText(eleSuccessMessage, dataSuccessMessage);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorMessage;
public CreateBundleAdvice verifyTextContainsErrorMessage(String error) {
	
	verifyPartialText(eleErrorMessage, error);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleWarningMessage;
public CreateBundleAdvice verifyTextContainsWarningMessage(String warning) {
	
	verifyPartialText(eleWarningMessage, warning);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleViewBundleSequenceNumbers;
public CreateBundleAdvice clickViewBundleSequenceNumbers(){
	click(eleViewBundleSequenceNumbers);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleCloseSuccessMessage;
public CreateBundleAdvice clickCloseSuccessMessage(){
	click(eleCloseSuccessMessage);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleCloseWarningMessage;
public CreateBundleAdvice clickCloseWarningMessage(){
	click(eleCloseWarningMessage);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBundleCodeDetails;
public CreateBundleAdvice verifyExistsBundleCodeDetails(){
	verifyExists(eleBundleCodeDetails);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBundleAdviceGenerated;
public CreateBundleAdvice verifyExistsBundleAdviceGenerated(){
	verifyExists(eleBundleAdviceGenerated);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleFromBundleSequenceNumber;
public CreateBundleAdvice verifyExistsFromBundleSequenceNumber(){
	verifyExists(eleFromBundleSequenceNumber);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleToBundleSequenceNumber;
public CreateBundleAdvice verifyExistsToBundleSequenceNumber(){
	verifyExists(eleToBundleSequenceNumber);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleCloseBundleSequenceNumberDetails;
public CreateBundleAdvice clickCloseBundleSequenceNumberDetails(){
	click(eleCloseBundleSequenceNumberDetails);
	return this;
}







}
