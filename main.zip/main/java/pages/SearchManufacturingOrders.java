package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SearchManufacturingOrders extends AbstractPage{

	String sessionId;

	public SearchManufacturingOrders() {
		PageFactory.initElements(getEventDriver(), this);
	}
	
	@FindBy(how = How.XPATH, using = "//span[@aria-owns='SearchFilter_OrderTypeCode_listbox']")
	private WebElement eleOrderType;
	
	@FindBy(how = How.XPATH, using = "//button[text()='Go']")
	private WebElement eleGo;
	
	@FindBy(how = How.XPATH, using = "//td[@role='gridcell']/a")
	private WebElement eleGridCell;
	
	public SearchManufacturingOrders selectOrderType(String type) {
		selectUsingText(eleOrderType,type);
		return this;
	}
	
	public SearchManufacturingOrders clickGo() {
		click(eleGo);
		return this;
	}
	
	public ManufacturingOrders clickGridCell() {
		click(eleGridCell);
		return new ManufacturingOrders();
	}
	
	

	
}
