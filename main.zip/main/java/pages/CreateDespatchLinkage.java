package pages;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.server.handler.SendKeys;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;



public class CreateDespatchLinkage extends AbstractPage {

	public CreateDespatchLinkage(){

		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}

	@FindBy(how=How.ID,using="view")
	WebElement eleview;
	public ViewDespatchLinkage clickView()
	{
		click(eleview);
		return new ViewDespatchLinkage();
	}

	@FindBy(how=How.CLASS_NAME,using="mandatory-star")
	private List<WebElement> eleMandatory;

	public CreateDespatchLinkage verifyMandatoryFields()
	{
		String[] elements = {"Order Number","Consignee Code","Lot Number"};
		System.out.println(verifyMandatory(elements));
		return this;

	}
	@FindBy(how=How.XPATH,using="//input[@id='OrderNumber']/../following-sibling::i")

	public WebElement eleClickOrderinfo;
	public CreateDespatchLinkage clickOrderinfo(){
		click(eleClickOrderinfo);
		return this;
	}

	@FindBy(how=How.XPATH,using="//div[@class='popover fade bottom in']")

	public WebElement eleGetIconinfo;
	public CreateDespatchLinkage verifyInfoDetails(){
		System.out.println(getText(eleGetIconinfo));
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='ConsigneeCode']/../following-sibling::i")

	public WebElement eleConsigneeinfo;
	public CreateDespatchLinkage clickConsigneeInfo(){
		click(eleConsigneeinfo);
		return this;
	}

	@FindBy(how=How.ID,using="OrderNumber")

	public WebElement eleOrderNumber;
	@When ("The orderNumber entered")
	public CreateDespatchLinkage typeOrderNumber(String orderNum){
		typeAndChoose(eleOrderNumber,orderNum);
		return this;
	}

	/*public CreateDespatchLinkage typeOrderNumber(String orderquery) throws FileNotFoundException, ClassNotFoundException, IOException, SQLException{

		String orderNum=getDatafromdatabase(orderquery);
		System.out.println(orderquery);
		typeAndChoose(eleOrderNumber,orderNum);
		return this;
	}*/

	@FindBy(how=How.ID,using="ConsigneeCode")

	public WebElement eleConsignee;
	@When ("Enter the  Consignee Code")
	public CreateDespatchLinkage typeConsignee(String consigneeNum){
		typeAndChoose(eleConsignee,consigneeNum);
		return this;
	}


	@FindBy(how=How.XPATH,using="(//span[text()='select'])[1]")   

	public WebElement eleLotNumber;

	public CreateDespatchLinkage clickLotNumber(){
		click(eleLotNumber);
		return this;
	}


	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]")   

	public WebElement eleItemsDropdown;

	public CreateDespatchLinkage clickItemsDropdown(){
		click(eleItemsDropdown);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]/../preceding-sibling::span")   

	public WebElement eleItemsDropdownText;

	public CreateDespatchLinkage getItemsDropdownText(){

		System.out.println(getText(eleItemsDropdownText));
		return this;
	}

	@FindBy(how=How.XPATH,using="(//span[@class='k-select'])[2]/../following-sibling::select")   

	public WebElement eleSelectItemsDropdown;

	public CreateDespatchLinkage selectItemsDropdown(String items){

		selectUsingText(eleSelectItemsDropdown, items);
		return this;
	}

	@When ("Select the lot number")
	public CreateDespatchLinkage SelectLotNumber(String lotNumber)
	{
		System.out.println(lotNumber);
		selectUsingText(locateElement("xpath", "//li[text()='"+lotNumber+"']"), lotNumber);
		return this;
	}


	@FindBy(how=How.ID,using="btnGo")

	public WebElement eleGo;
	@And ("Click Get Products")

	public CreateDespatchLinkage clickGetProducts(){
		click(eleGo);
	
		return this;
	}


	@FindBy(how=How.XPATH,using="//span[@class='k-pager-info k-label']")

	public WebElement eleDisplayItems;

	public CreateDespatchLinkage gedisplayOfItems(){
		System.out.println(getText(eleDisplayItems));
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@class='k-pager-sizes k-label']")

	public WebElement eleItemsPerPage;

	public CreateDespatchLinkage getItemsPerPage(){
		if(getText(eleItemsPerPage).contains("items per page"))

			System.out.println("Items per page text is displayed in the UI");

		else

			System.out.println("Items per page text is not displayed in the UI");

		return this;
	}


	@FindBy(how=How.XPATH,using="//span[text()='seek-w']")

	public WebElement eleLeftDoubleArrow;

	public CreateDespatchLinkage clickDoubleLeftArrow(){
		click(eleLeftDoubleArrow);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']")

	public WebElement eleLeftArrow;

	public CreateDespatchLinkage clickLeftArrow(){
		click(eleLeftArrow);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")

	public WebElement eleRightArrow;

	public CreateDespatchLinkage clickRightArrow(){
		click(eleRightArrow);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='seek-e']")

	public WebElement eleRightDoubleArrow;

	public CreateDespatchLinkage clickDoubleRightArrow(){
		click(eleRightDoubleArrow);
		return this;
	}

	@FindBy(how=How.ID,using="btnyes")    

	public WebElement eleYesConfirmation;
	@When ("Click on Yes")
	public CreateDespatchLinkage clickYesConfirmation(){
		System.out.println(getText(eleYesConfirmation));
		click(eleYesConfirmation);
		return this;
	}
	
	@FindBy(how=How.ID,using="btnno")    

	public WebElement eleNoConfirmation;
	@When ("Click on Yes")
	public CreateDespatchLinkage clickNoConfirmation(){
		System.out.println(getText(eleYesConfirmation));
		click(eleNoConfirmation);
		return this;
	}
/*
	@FindBy(how=How.XPATH,using="//span[@id='kendoWindow_wnd_title']/following-sibling::div/a")    
	public WebElement eleSuccess;
	public CreateDespatchLinkage closeSuccess(){
		click(eleSuccess);
		return this;
	}*/




	/*@FindBy(how=How.ID,using="lblwindowmsg")    
	public WebElement eleMessage;
	public CreateDespatchLinkage getDispatchLinkageNumber(){
		System.out.println(getText(eleMessage));
		return this;
	}
*/

	@FindBy(how=How.ID,using="btnSubmit")    

	public WebElement eleSubmit;
	@When ("Click on submit")
	public CreateDespatchLinkage clickSubmit(){
		if(eleSubmit.isEnabled())
			click(eleSubmit);
		else
			reportStep("The Submit button is not enabled","FAIL");
		return this;
	}


	@FindBy(how=How.ID,using="btnReset")

	public WebElement eleReset;
	public CreateDespatchLinkage clickReset(){
		click(eleReset);
		return this;
	}

	@FindBy(how=How.XPATH,using="//div[@id='grdDespatchLinkage']//tbody/tr")
	List<WebElement> elerecords;

	public int getNumberOfDispatchRecords()
	{
		System.out.println("rows are"+elerecords.size());
		return elerecords.size();
	}

	
	public int getToBeLinkedQuantity(int i){

		System.out.println("The quantity is"+getText(locateWebTableElement("Quantity", i)));
		System.out.println("The quantity is"+getText(locateWebTableElement("Previous Linked Quantity", i)));
		int canLinkQty = Integer.parseInt(getText(locateWebTableElement("Quantity", i))) - Integer.parseInt(getText(locateWebTableElement("Previous Linked Quantity", i)));
		int quantity= new Random().nextInt(canLinkQty)+1;
		System.out.println(quantity);
		return quantity;
	}

	public int getQuantity(int i){
		return Integer.parseInt(getText(locateWebTableElement("Quantity", i)));
	}

	@And ("Enter the quantity to be linked")
	public CreateDespatchLinkage typeToBeLinked(String columnName) {
		/*int i=1;
		while(i<=noOfRecords()) {

			click(locateWebTableElement(columnName, i));
			typeAndTab(locateElement("xpath", "((//textarea[contains(@id,'grdTobeLinked')])["+i+"])"), Integer.toString(getQuantity(i)));
			i++;
			if(i==(noOfRecords()+1))
			{
				locateElement("xpath","//span[text()='items per page']//span[text()='select']").sendKeys(Keys.TAB);
			}

		}
		 */

		return this;
	}
	@And ("Enter the quantity to be linked")
	public CreateDespatchLinkage enterQuantityForAllToBeLinked() {

		int rows = getNumberOfDispatchRecords();
		for (int i = 1; i <= rows; i++) {
			click(locateWebTableElement("To be Linked", i));
			WebElement linkedQty = locateElement("xpath", "(//textarea[@placeholder='Enter Linked Quantity'])["+i+"]");
			type(linkedQty, ""+(getQuantity(i)+1));
		}

		return this;
	}

	@And ("Enter the quantity to be linked")
	public CreateDespatchLinkage enterQuantityAboveExpected() {

		click(locateWebTableElement("To be Linked", 1));
		WebElement linkedQty = locateElement("xpath", "(//textarea[@placeholder='Enter Linked Quantity'])[1]");
		typeAndTab(linkedQty, ""+(getToBeLinkedQuantity(1)+1));
		return this;
	}


	@FindBy(how=How.ID,using="kendoWindow_wnd_title")
	private WebElement eledialogTitle;
	public CreateDespatchLinkage getdialogTitle() 
	{
		System.out.println(getText(eledialogTitle));

		return this;
	}


	@FindBy(how=How.ID,using="lblwindowmsg")
	private WebElement eledialogMsg;
	public CreateDespatchLinkage getdialogMsg() 
	{
		System.out.println(getText(eledialogMsg));

		return this;
	}

	@FindBy(how=How.XPATH,using="(//span[text()='Close']/..)[1]") 
	public WebElement closeMessage; 
	public CreateDespatchLinkage  CloseMessage()
	{
		click(closeMessage);
		return this;
	}

}
