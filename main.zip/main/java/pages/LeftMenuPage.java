package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class LeftMenuPage extends AbstractPage{
	
	public LeftMenuPage() {
		PageFactory.initElements(getEventDriver(), this);		
	}

	@FindBy(how = How.XPATH, using = "(//i[@class='PDSSNavigation fa fa-bars'])[2]")
	private WebElement eleNavigation;

	@FindBy(how = How.LINK_TEXT, using = "Document")
	private WebElement eleDocument;

	@FindBy(how = How.LINK_TEXT, using = "Order Mgmt.")
	private WebElement eleOrderMgmt;

	@FindBy(how = How.LINK_TEXT, using = "Manufacturing Orders")
	private WebElement eleManufacturingOrders;
	@And ("Click on Despatch Menu Item")
	public LeftMenuPage clickNavigation() {
		click(eleNavigation);
		return this;
	}
	@And ("Click on Documents Sub Menu")
	public LeftMenuPage clickDocument() {
		click(eleDocument);
		return this;
	}

	public LeftMenuPage clickOrderMgmt() {
		click(eleOrderMgmt);
		return this;
	}

	public SearchManufacturingOrders clickManufacturingOrders() {
		click(eleManufacturingOrders);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {			
		}
		return new SearchManufacturingOrders();
	}


	@FindBy(how=How.LINK_TEXT,using="Sales and Distribution")

	public WebElement eleSalesandDistribution;
	public LeftMenuPage clickSalesandDistribution(){
		click(eleSalesandDistribution);
		return this;
	}
	
	@FindBy(how=How.LINK_TEXT,using="Despatch BOM - Panel")

	public WebElement eleDespatchBOMPanel;
	public PanelEssentialsView clickDespatchBOMPanel(){
		click(eleDespatchBOMPanel);
		return new PanelEssentialsView();
	}
	
	@FindBy(how=How.XPATH,using="//ul[@id='Despatch']/preceding-sibling::a")
	
	public WebElement eleDespatch;
	@And ("Click on Despatch Menu Item")
	public LeftMenuPage clickDespatch(){
		click(eleDespatch);
		return this;
	}
	
	//@FindBy(how=How.XPATH,using="//ul[@id='Despatch']//a")
	@FindBy(how=How.XPATH,using="//ul[@id='Despatch']//a[text()[contains(.,'Despatch Linkage')]]")

	public WebElement eleDespatchLinkage;
	@And ("Click on Despatch Linkage")
	public ViewDespatchLinkage clickDespatchLinkage(){;
		click(eleDespatchLinkage);
		return new ViewDespatchLinkage();
	}
	
	@FindBy(how=How.LINK_TEXT,using="Bundle Advise")

	public WebElement eleBundleAdvise;
	public ViewBundleAdvice clickBundleAdvise(){
		click(eleBundleAdvise);
		return new ViewBundleAdvice();
	}



}
