package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.When;



public class ViewDespatchLinkage extends AbstractPage  {

	public ViewDespatchLinkage(){

		PageFactory.initElements(getEventDriver(), this);

	}
	
	@FindBy(how=How.ID,using="Create")

	public WebElement eleCreate;
	@When ("Click on Create")
	public CreateDespatchLinkage clickCreate(){
		click(eleCreate);
		return new CreateDespatchLinkage();
	}

	@FindBy(how=How.CLASS_NAME,using="lti-mand")

	private WebElement eleMandate;
	
	public CreateDespatchLinkage verifyMandate(){
		if(getText(eleMandate).contains("*"))
			System.out.println("The "+ getText(locateElement("xpath", "//span[@class='lti-mand']/.."))+" is displayed as Mandatory field");
		return new CreateDespatchLinkage();
	}
	
	
	
	@FindBy(how=How.ID,using="LinkageNo")

	public WebElement eleLinkageNo;
	
	public CreateDespatchLinkage typeLinkageNo(String linkageNumber){
		typeAndChoose(eleLinkageNo,linkageNumber);
		return new CreateDespatchLinkage();
	}
	
	@FindBy(how=How.ID,using="OrderNumber")

	public WebElement eleOrderNumber;
	@When ("The orderNumber entered")
	public ViewDespatchLinkage typeOrderNumber(String orderNumber){
		typeAndChoose(eleOrderNumber,orderNumber);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='OrderNumber']/../following-sibling::i")

	public WebElement eleOrderinfo;
	public ViewDespatchLinkage clickOrderinfo(String dataWarningMessage){
		click(eleOrderinfo);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='ConsigneeCode']/../following-sibling::i")

	public WebElement eleConsigneeinfo;
	public ViewDespatchLinkage clickConsigneeInfo(String dataWarningMessage){
		click(eleConsigneeinfo);
		return this;
	}

	@FindBy(how=How.ID,using="ConsigneeCode")

	public WebElement eleConsignee;
	@When ("Enter the  Consignee Code")
	public ViewDespatchLinkage typeConsignee(String consigneeNum){
		typeAndChoose(eleConsignee,consigneeNum);
		return this;
	}
	
	@FindBy(how=How.ID,using="btnGo")

	public WebElement eleGo;
	public ViewDespatchLinkage clickgo(){
		click(eleGo);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='Close']/..")

	public WebElement eleError;
	public ViewDespatchLinkage CloseError(){
		click(eleError);
		return this;
	}

	@FindBy(how=How.ID,using="btnReset")

	public WebElement eleReset;
	public ViewDespatchLinkage clickReset(){
		click(eleReset);
		return this;
	}
	
	
}

