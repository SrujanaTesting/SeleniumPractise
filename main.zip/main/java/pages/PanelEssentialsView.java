package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PanelEssentialsView extends AbstractPage  {

	public PanelEssentialsView(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}
	@FindBy(how=How.ID,using="Create")

	public WebElement eleCreate;
	public PanelEssentialsCreate clickCreate(){
		click(eleCreate);
		return new PanelEssentialsCreate();
	}


}
