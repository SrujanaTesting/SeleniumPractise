package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class ViewBundleAdvice extends AbstractPage  {

	public ViewBundleAdvice(){
		// This is to load all the elements in the page
		PageFactory.initElements(driver, this);

	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleCreate;
	public CreateBundleAdvice clickCreate(){
		click(eleCreate);
		return new CreateBundleAdvice();
	}


}
