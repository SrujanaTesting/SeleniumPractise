package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;

public class LoginPage extends AbstractPage{
	
	String sessionId ="";

	public LoginPage() {
		PageFactory.initElements(getEventDriver(), this);
	}

	@FindBy(how = How.ID, using = "txtUserName")
	private WebElement eleUName;

	@FindBy(how = How.ID, using = "txtPassword")
	private WebElement elePassword;

	@FindBy(how = How.ID, using = "btnLogin")
	private WebElement eleLogin;
	@And("Username is entered")
	public LoginPage enterUserName(String data) {
		typeAndTab(eleUName, data);
		return this;
	}
	@And("Password is entered")
	public LoginPage enterPassword(String data) {
		System.out.println(getAttributeText(elePassword, "value").trim());
		if(getAttributeText(elePassword, "value").trim().equals(""))
			type(elePassword, data);
		return this;
	}
	@When("Click on Login")
	public LeftMenuPage clickLogin() {
		
		click(eleLogin);
		
		String currentUrl = getEventDriver().getCurrentUrl();		
		if(currentUrl.contains(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=")) {
			sessionId = currentUrl.replace(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=", "");
		}
		getEventDriver().get(config.getProperty("URL")+"/EIPPDSS/CommonGetSession.aspx?strpage=PDSHome/PDSHome&SessionID="+sessionId);

		return new LeftMenuPage();
	}

}
